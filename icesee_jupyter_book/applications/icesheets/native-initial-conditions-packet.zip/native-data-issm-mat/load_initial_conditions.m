function [cfg,g]=load_initial_conditions(filename)
% Portable numeric MATLAB struct; not an ISSM model object or observations.
info=dir(filename); assert(isscalar(info) && info.bytes<=2*1024*1024,'Initial fields exceed 2 MiB');
d=load(filename,'initial_conditions');
assert(isfield(d,'initial_conditions') && isstruct(d.initial_conditions) && isscalar(d.initial_conditions),'Expected one initial_conditions struct');
g=d.initial_conditions;
assert(isfield(g,'schema') && ischar(g.schema) && strcmp(g.schema,'cryostack.shelf-initial-fields.v1'),'Wrong initial-fields schema');
assert(isfield(g,'model') && ischar(g.model) && strcmp(g.model,'issm'),'Wrong model');
assert(isfield(g,'synthetic') && isnumeric(g.synthetic) && isscalar(g.synthetic) && g.synthetic==1,'Retain synthetic provenance');
assert(isfield(g,'units') && isstruct(g.units) && isscalar(g.units),'Missing units');
names={'x','y','thickness','base','surface','vx','vy','floating_mask'};
units={'m','m','m','m','m','m/year','m/year','1'};
for k=1:numel(names)
    n=names{k}; assert(isfield(g,n),['Missing field: ' n]); value=g.(n);
    assert(isnumeric(value) && isreal(value) && numel(value)<=4096 && all(isfinite(value(:))),['Invalid field: ' n]);
    assert(isfield(g.units,n) && ischar(g.units.(n)) && strcmp(g.units.(n),units{k}),['Wrong units: ' n]);
end
g.x=double(g.x(:)'); g.y=double(g.y(:));
assert(numel(g.x)>=2 && numel(g.x)<=64 && numel(g.y)>=2 && numel(g.y)<=64 && all(diff(g.x)>0) && all(diff(g.y)>0),'Invalid axes');
assert(g.x(1)==0 && g.y(1)==0 && g.x(end)>=100 && g.x(end)<=100000 && g.y(end)>=100 && g.y(end)<=100000,'Invalid domain bounds');
for k=3:numel(names), assert(isequal(size(g.(names{k})),[numel(g.y),numel(g.x)]),'Fields must have shape (ny,nx)'); end
assert(all(g.thickness(:)>=1 & g.thickness(:)<=2000) && all(g.floating_mask(:)==1),'Invalid thickness or floating mask');
assert(isfield(g,'rho_ice_kg_m3') && isnumeric(g.rho_ice_kg_m3) && isscalar(g.rho_ice_kg_m3) && isfinite(g.rho_ice_kg_m3) && g.rho_ice_kg_m3>=900 && g.rho_ice_kg_m3<=930,'Invalid ice density');
assert(isfield(g,'rho_water_kg_m3') && isnumeric(g.rho_water_kg_m3) && isscalar(g.rho_water_kg_m3) && isfinite(g.rho_water_kg_m3) && g.rho_water_kg_m3>=1000 && g.rho_water_kg_m3<=1040,'Invalid water density');
assert(max(abs(g.base(:)+g.rho_ice_kg_m3/g.rho_water_kg_m3*g.thickness(:)))<1e-8,'Inconsistent floating base');
assert(max(abs(g.surface(:)-g.base(:)-g.thickness(:)))<1e-8,'Inconsistent surface');
assert(all(abs(g.vx(:))<=2000) && all(abs(g.vy(:))<=2000),'Invalid velocity');
assert(isfield(g,'temperature_K') && isnumeric(g.temperature_K) && isscalar(g.temperature_K) && isfinite(g.temperature_K) && g.temperature_K>=200 && g.temperature_K<=273.15,'Invalid temperature');
cfg=struct('schema','cryostack.synthetic-shelf.v1','model','issm','synthetic',true,...
 'units',struct('length','m','thickness','m','temperature','K','velocity','m/year'),...
 'length_m',g.x(end),'width_m',g.y(end),'thickness_min_m',min(g.thickness(:)),...
 'thickness_max_m',max(g.thickness(:)),'temperature_K',g.temperature_K,...
 'mesh_nx',4,'mesh_ny',4,'mesh_spacing_m',2500,...
 'inflow_velocity_m_per_year',g.vx(1,1),'timesteps',1,'dt_years',0.01);
validate_launch_dataset(cfg);
end
