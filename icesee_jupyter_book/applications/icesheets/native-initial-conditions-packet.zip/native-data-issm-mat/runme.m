% Synthetic launch shelf. Run from this directory with ISSM on MATLAB's path.
launch_started=tic;
[cfg,input_grid]=load_initial_conditions(fullfile('data','issm-shelf-initial.mat'));
validate_launch_dataset(cfg);
L=cfg.length_m; W=cfg.width_m;
fid=fopen('LaunchDomain.exp','w'); assert(fid>=0,'Cannot write synthetic domain');
fprintf(fid,'## Name:LaunchDomain\n## Icon:0\n# Points Count Value\n5 1\n# X pos Y pos\n0 0\n%g 0\n%g %g\n0 %g\n0 0\n',L,L,W,W); fclose(fid);
fid=fopen('LaunchFront.exp','w'); assert(fid>=0,'Cannot write synthetic front');
fprintf(fid,'## Name:LaunchFront\n## Icon:0\n# Points Count Value\n5 1\n# X pos Y pos\n%g %g\n%g %g\n%g %g\n%g %g\n%g %g\n',L-1,-1,L+1,-1,L+1,W+1,L-1,W+1,L-1,-1); fclose(fid);
md=model;
md=triangle(md,'LaunchDomain.exp',cfg.mesh_spacing_m);
md=setmask(md,'all','');
md=parameterize(md,'Launch.par');
outdir=fullfile(pwd,'outputs'); if ~isfolder(outdir), mkdir(outdir); end
initial_fields=struct('x',md.mesh.x,'y',md.mesh.y,'thickness',md.geometry.thickness,...
 'base',md.geometry.base,'surface',md.geometry.surface,'vx',md.initialization.vx,'vy',md.initialization.vy);
save(fullfile(outdir,'initial-fields-on-native-mesh.mat'),'initial_fields');
fprintf('NATIVE_DATA initialized full MAT geometry and velocity fields on all %d native vertices\n',md.mesh.numberofvertices);
f=figure('Visible','off');
subplot(1,3,1); trisurf(md.mesh.elements,md.mesh.x,md.mesh.y,md.geometry.thickness,'EdgeColor','none'); view(2); axis equal tight; colorbar; title('Initial thickness (m)');
subplot(1,3,2); trisurf(md.mesh.elements,md.mesh.x,md.mesh.y,md.geometry.surface,'EdgeColor','none'); view(2); axis equal tight; colorbar; title('Initial surface (m)');
subplot(1,3,3); trisurf(md.mesh.elements,md.mesh.x,md.mesh.y,md.initialization.vel,'EdgeColor','none'); view(2); axis equal tight; colorbar; title('Initial speed (m/year)');
saveas(f,fullfile(outdir,'initial-conditions.png')); close(f);

md=setflowequation(md,'SSA','all');
md.cluster=generic('name',oshostname,'np',1);
% Container installations can be read-only; use this example's writable area.
md.cluster.executionpath=fullfile(pwd,'execution');
if ~isfolder(md.cluster.executionpath), mkdir(md.cluster.executionpath); end
for launch_step=1:cfg.timesteps
    % Repeated diagnostic solves exercise monitoring; physical time is unchanged.
    md=solve(md,'Stressbalance');
    fprintf('SOFT_LAUNCH step=%d/%d\n',launch_step,cfg.timesteps);
end
v=md.results.StressbalanceSolution.Vel;
assert(all(isfinite(v)),'Nonfinite velocity');
assert(all(isfinite(md.geometry.thickness)) && all(md.geometry.thickness>0),'Invalid thickness');
metrics=struct('model','issm','case','synthetic-shelf-v1','steps',cfg.timesteps,...
 'thickness_min',min(md.geometry.thickness),'thickness_max',max(md.geometry.thickness),...
 'thickness_mean',mean(md.geometry.thickness),'speed_l2',sqrt(mean(v.^2)),...
 'runtime_seconds',toc(launch_started));
outdir=fullfile(pwd,'outputs');
if ~isfolder(outdir), mkdir(outdir); end
fid=fopen(fullfile(outdir,'reference-metrics.json'),'w'); assert(fid>=0);
fprintf(fid,'%s\n',jsonencode(metrics)); fclose(fid);
save(fullfile(outdir,'md_launch.mat'),'md','-v7.3');
disp(jsonencode(metrics));
