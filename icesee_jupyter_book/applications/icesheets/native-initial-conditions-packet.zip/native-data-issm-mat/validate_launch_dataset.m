function validate_launch_dataset(c)
assert(isstruct(c) && isscalar(c),'Expected one configuration object');
assert(isfield(c,'schema') && strcmp(c.schema,'cryostack.synthetic-shelf.v1'),'Wrong schema');
assert(isfield(c,'model') && strcmp(c.model,'issm'),'Wrong model');
assert(isfield(c,'synthetic') && isequal(c.synthetic,true),'Missing synthetic label');
assert(isfield(c,'units') && isstruct(c.units),'Missing units');
u=c.units;
assert(isfield(u,'length') && strcmp(u.length,'m') && isfield(u,'thickness') && strcmp(u.thickness,'m') && isfield(u,'temperature') && strcmp(u.temperature,'K') && isfield(u,'velocity') && strcmp(u.velocity,'m/year'),'Wrong units');
names={'length_m','width_m','thickness_min_m','thickness_max_m','temperature_K','mesh_nx','mesh_ny','mesh_spacing_m','inflow_velocity_m_per_year','timesteps','dt_years'};
lower=[100 100 1 1 200 2 2 100 0 1 0.0001];
upper=[100000 100000 2000 2000 273.15 32 32 50000 1000 6 0.1];
for k=1:numel(names)
    name=names{k}; assert(isfield(c,name),['Missing field: ' name]); value=c.(name);
    assert(isnumeric(value) && isscalar(value) && isfinite(value) && value>=lower(k) && value<=upper(k),['Invalid field: ' name]);
end
assert(c.thickness_max_m>=c.thickness_min_m,'Inverted thickness');
assert(c.mesh_nx==floor(c.mesh_nx) && c.mesh_ny==floor(c.mesh_ny) && c.timesteps==floor(c.timesteps),'Mesh counts and timesteps must be integers');
assert(c.mesh_spacing_m>=min(c.length_m,c.width_m)/32,'Mesh exceeds bounded launch case');
end
