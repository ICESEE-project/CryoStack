"""Bounded portable HDF5 initial fields, not a Firedrake checkpoint reader."""
from pathlib import Path
import h5py
import numpy as np

SCHEMA = "cryostack.shelf-initial-fields.v1"
UNITS = {"x": "m", "y": "m", "thickness": "m", "base": "m",
         "surface": "m", "vx": "m/year", "vy": "m/year", "floating_mask": "1"}


def _text(value):
    return value.decode("utf-8") if isinstance(value, bytes) else str(value)


def read_initial_conditions(handle, model="icepack"):
    """Validate the whole grid before constructing or allocating a solver mesh."""
    if _text(handle.attrs.get("schema", "")) != SCHEMA:
        raise ValueError("Wrong initial-fields schema")
    if _text(handle.attrs.get("model", "")) != model:
        raise ValueError("Wrong initial-fields model")
    if int(handle.attrs.get("synthetic", 0)) != 1:
        raise ValueError("This recording fixture must retain its synthetic label")
    fields = {}
    for name, units in UNITS.items():
        key = ("coordinates/" if name in ("x", "y") else "fields/") + name
        # No external/soft links or lazy virtual datasets in an uploaded fixture.
        for prefix in (key.split("/")[0], key):
            if not isinstance(handle.get(prefix, getlink=True), h5py.HardLink):
                raise ValueError("Only contained HDF5 datasets are allowed")
        ds = handle[key]
        if not isinstance(ds, h5py.Dataset) or ds.is_virtual or ds.external:
            raise ValueError("Only contained numeric HDF5 datasets are allowed")
        if ds.dtype.kind not in "fiu" or ds.size > 4096 or ds.ndim > 2:
            raise ValueError("Invalid numeric field type or size: " + name)
        if _text(ds.attrs.get("units", "")) != units:
            raise ValueError("Wrong units: " + name)
        data = np.asarray(ds[...], dtype=float)
        if not np.isfinite(data).all():
            raise ValueError("Nonfinite initial field: " + name)
        fields[name] = data
    for name in ("x", "y"):
        axis = fields[name]
        if axis.ndim != 1 or not 2 <= axis.size <= 64 or not np.all(np.diff(axis) > 0):
            raise ValueError("Axes must be finite, strictly increasing vectors")
        if axis[0] != 0 or not 100 <= axis[-1] <= 100000:
            raise ValueError("Axis exceeds bounded recording domain")
    shape = (fields["y"].size, fields["x"].size)
    if any(fields[name].shape != shape for name in UNITS if name not in ("x", "y")):
        raise ValueError("Every field must have shape (ny,nx)")
    h, b, s = (fields[n] for n in ("thickness", "base", "surface"))
    if not ((h >= 1) & (h <= 2000)).all():
        raise ValueError("Thickness outside recording bounds")
    if not (fields["floating_mask"] == 1).all():
        raise ValueError("IceShelf fixture supports floating cells only")
    rho_i = float(handle.attrs.get("rho_ice_kg_m3", 0))
    rho_w = float(handle.attrs.get("rho_water_kg_m3", 0))
    if not (900 <= rho_i <= 930 and 1000 <= rho_w <= 1040):
        raise ValueError("Invalid water/ice density")
    if not np.allclose(b, -rho_i / rho_w * h, rtol=0, atol=1e-8):
        raise ValueError("Floating base is inconsistent with thickness")
    if not np.allclose(s, b + h, rtol=0, atol=1e-8):
        raise ValueError("Surface/base/thickness are inconsistent")
    if any((np.abs(fields[n]) > 2000).any() for n in ("vx", "vy")):
        raise ValueError("Velocity outside recording bounds")
    cfg = {"schema": "cryostack.synthetic-shelf.v1", "model": model, "synthetic": True,
           "units": {"length": "m", "thickness": "m", "temperature": "K", "velocity": "m/year"},
           "length_m": float(fields["x"][-1]), "width_m": float(fields["y"][-1]),
           "thickness_min_m": float(h.min()), "thickness_max_m": float(h.max()),
           "temperature_K": float(handle.attrs.get("temperature_K", 0)),
           "mesh_nx": 4, "mesh_ny": 4, "mesh_spacing_m": 2500.,
           "inflow_velocity_m_per_year": float(fields["vx"][0, 0]),
           "timesteps": 1, "dt_years": .01,
           "rho_ice_kg_m3": rho_i, "rho_water_kg_m3": rho_w}
    if not 200 <= cfg["temperature_K"] <= 273.15:
        raise ValueError("Invalid temperature")
    return cfg, fields


def load_initial_conditions(source, model="icepack"):
    path = Path(source)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("Initial-fields file exceeds 2 MiB")
    with h5py.File(path, "r") as handle:
        return read_initial_conditions(handle, model)


def sample_field(fields, name, x_nodes, y_nodes):
    """Bilinearly interpolate every query point, rejecting uncovered nodes."""
    x, y = fields["x"], fields["y"]
    qx, qy = np.asarray(x_nodes), np.asarray(y_nodes)
    if qx.shape != qy.shape or not (np.isfinite(qx).all() and np.isfinite(qy).all()):
        raise ValueError("Invalid query coordinates")
    if (qx < x[0] - 1e-8).any() or (qx > x[-1] + 1e-8).any() or (qy < y[0] - 1e-8).any() or (qy > y[-1] + 1e-8).any():
        raise ValueError("Initial field does not cover native mesh")
    qx, qy = np.clip(qx, x[0], x[-1]), np.clip(qy, y[0], y[-1])
    i = np.clip(np.searchsorted(x, qx, side="right") - 1, 0, len(x) - 2)
    j = np.clip(np.searchsorted(y, qy, side="right") - 1, 0, len(y) - 2)
    a, b = (qx - x[i]) / (x[i + 1] - x[i]), (qy - y[j]) / (y[j + 1] - y[j])
    f = fields[name]
    return ((1 - a) * (1 - b) * f[j, i] + a * (1 - b) * f[j, i + 1]
            + (1 - a) * b * f[j + 1, i] + a * b * f[j + 1, i + 1])
