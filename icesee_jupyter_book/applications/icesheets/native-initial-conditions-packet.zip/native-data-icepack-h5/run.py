"""Synthetic shelf: native Icepack solve; keep h/u globals for CryoLauncher export."""
import json
import time
from pathlib import Path
from initial_fields import load_initial_conditions, sample_field

started=time.monotonic()
p=Path('data/icepack-shelf-initial.h5')
cfg,initial=load_initial_conditions(p,'icepack')  # Validate before expensive imports or meshing.
import firedrake as fd
import icepack
import numpy as np
import matplotlib.pyplot as plt

mesh=fd.RectangleMesh(cfg['mesh_nx'],cfg['mesh_ny'],cfg['length_m'],cfg['width_m'])
Q=fd.FunctionSpace(mesh,'CG',1)
V=fd.VectorFunctionSpace(mesh,'CG',1)
x,y=fd.SpatialCoordinate(mesh)
h0=fd.Function(Q)
# Initialize every native mesh-node value from the uploaded HDF5 fields.
x_nodes=fd.Function(Q).interpolate(x)
y_nodes=fd.Function(Q).interpolate(y)
qx=x_nodes.dat.data_ro
qy=y_nodes.dat.data_ro
h0.dat.data[:]=sample_field(initial,'thickness',qx,qy)
b0=fd.Function(Q); b0.dat.data[:]=sample_field(initial,'base',qx,qy)
s0=fd.Function(Q); s0.dat.data[:]=sample_field(initial,'surface',qx,qy)
u0=fd.Function(V)
# Use the vector space's own coordinate nodes; never assume scalar/vector order.
vx_nodes=fd.Function(V).interpolate(fd.as_vector((x,y))).dat.data_ro
u0.dat.data[:,0]=sample_field(initial,'vx',vx_nodes[:,0],vx_nodes[:,1])
u0.dat.data[:,1]=sample_field(initial,'vy',vx_nodes[:,0],vx_nodes[:,1])
Path('outputs').mkdir(exist_ok=True)
np.savez('outputs/initial-fields-on-native-mesh.npz',x=qx,y=qy,thickness=h0.dat.data_ro,
         base=b0.dat.data_ro,surface=s0.dat.data_ro,velocity=u0.dat.data_ro,
         velocity_coordinates=vx_nodes.copy())
print('NATIVE_DATA initialized full HDF5 thickness/base/surface/velocity fields on native mesh',flush=True)
fig,axes=plt.subplots(1,3,figsize=(12,4))
for ax,field,label in zip(axes,(h0,s0,fd.Function(Q).interpolate(fd.sqrt(fd.inner(u0,u0)))),
                          ('Initial thickness (m)','Initial surface (m)','Initial speed (m/year)')):
    colors=fd.tripcolor(field,axes=ax);fig.colorbar(colors,ax=ax);ax.set_title(label)
fig.tight_layout();fig.savefig('outputs/initial-conditions.png',dpi=140)
h=h0.copy(deepcopy=True)
A=icepack.rate_factor(fd.Constant(cfg['temperature_K']))
solver=icepack.solvers.FlowSolver(icepack.models.IceShelf(),dirichlet_ids=[1],side_wall_ids=[3,4])
u=solver.diagnostic_solve(velocity=u0,thickness=h,fluidity=A)
a=fd.Function(Q).assign(0)
for step in range(cfg['timesteps']):
    h=solver.prognostic_solve(cfg['dt_years'],thickness=h,velocity=u,accumulation=a,thickness_inflow=h0)
    u=solver.diagnostic_solve(velocity=u,thickness=h,fluidity=A)
    print(f'SOFT_LAUNCH step={step+1}/{cfg["timesteps"]}',flush=True)
assert np.isfinite(h.dat.data_ro).all() and np.min(h.dat.data_ro)>0
assert np.isfinite(u.dat.data_ro).all()
metrics=dict(model='icepack',case='synthetic-shelf-v1',steps=cfg['timesteps'],
             thickness_min=float(h.dat.data_ro.min()),thickness_max=float(h.dat.data_ro.max()),
             thickness_mean=float(fd.assemble(h*fd.dx)/(cfg['length_m']*cfg['width_m'])),
             speed_l2=float(np.sqrt(fd.assemble(fd.inner(u,u)*fd.dx)/(cfg['length_m']*cfg['width_m']))),
             runtime_seconds=time.monotonic()-started)
Path('outputs').mkdir(exist_ok=True)
Path('outputs/reference-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
fig,axes=plt.subplots(); colors=fd.tripcolor(h,axes=axes); fig.colorbar(colors,ax=axes,label='Thickness (m)')
axes.set_title('Synthetic shelf: final thickness'); print(json.dumps(metrics),flush=True)
