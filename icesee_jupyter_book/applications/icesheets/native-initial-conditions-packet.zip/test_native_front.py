"""Check the generated MAT calving contour against the initial-field direction."""
import ast
import math
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parent


def numeric(expression,L=10000.,W=10000.):
    node=ast.parse(expression,mode='eval').body
    def visit(n):
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return n.value
        if isinstance(n,ast.Name) and n.id in ('L','W'):return {'L':L,'W':W}[n.id]
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -visit(n.operand)
        if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub)):
            return visit(n.left)+visit(n.right) if isinstance(n.op,ast.Add) else visit(n.left)-visit(n.right)
        raise ValueError('Unexpected generated contour expression')
    return visit(node)


def actual_contour():
    line=next(s for s in (ROOT/'native-data-issm-mat/runme.m').read_text().splitlines() if "fprintf(fid,'## Name:LaunchFront" in s)
    arguments=line.split("',",1)[1].split(');',1)[0]
    coordinates=[numeric(s) for s in arguments.split(',')]
    return list(zip(coordinates[::2],coordinates[1::2]))


def inside(x,y,polygon):
    result=False
    for (x1,y1),(x2,y2) in zip(polygon,polygon[1:]):
        if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1)+x1:result=not result
    return result


class NativeFrontTests(unittest.TestCase):
    def test_contour_closed_narrow_east_edge(self):
        p=actual_contour();self.assertEqual(len(p),5);self.assertEqual(p[0],p[-1])
        self.assertEqual({x for x,y in p},{9999.,10001.})
        self.assertEqual({y for x,y in p},{-1.,10001.})

    def test_all_east_edge_samples_are_front(self):
        self.assertTrue(all(inside(10000,y,actual_contour()) for y in range(0,10001,100)))

    def test_other_edges_excluding_east_corners_are_not_front(self):
        p=actual_contour()
        self.assertFalse(any(inside(0,y,p) for y in range(0,10001,100)))
        self.assertFalse(any(inside(x,y,p) for x in range(0,9901,100) for y in (0,10000)))

    def test_initial_velocity_is_outward_on_entire_front(self):
        # Analytic fields used to write HDF5/MAT: normal is +x at x=L.
        for y in range(0,10001,100):
            vx=180+5*math.sin(math.pi*y/10000)
            vy=2*math.sin(math.pi*y/10000)*math.sin(math.pi)
            self.assertGreater(vx,0);self.assertLess(abs(vy),1e-12)


if __name__=='__main__':unittest.main()
