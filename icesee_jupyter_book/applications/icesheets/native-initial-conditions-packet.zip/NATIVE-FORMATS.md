HDF5 and MAT initial-condition recording cases, 18 November 2026
================================================================

These inputs are synthetic analytic floating shelves. They are not observational
community datasets, Firedrake checkpoints, or serialized ISSM model objects.
Their purpose is to demonstrate genuine native model initialization from familiar
scientific file formats, through the existing owned-example and BYO AWS workflow.
Existing canonical Icepack and ISSM native acceptance is unchanged.

Primary data cases
------------------

Icepack: add `run.py` and `initial_fields.py` from `native-data-icepack-h5/` to an
owned example. Upload `datasets/icepack-shelf-initial.h5`, then **Reference in
example** with alias `icepack-shelf-initial.h5` (or blank alias for the same
filename). The script reads `data/icepack-shelf-initial.h5`.

ISSM: add `runme.m`, `Launch.par`, `validate_launch_dataset.m`, and
`load_initial_conditions.m` from `native-data-issm-mat/`. Upload
`datasets/issm-shelf-initial.mat` and reference it with alias
`issm-shelf-initial.mat`. Keep the existing saved MATLAB configuration and
same-owner Connector connected. No new license or account is required.

For each case, explicitly choose the existing BYO AWS execution route, review
the connected account/resources and estimate, launch, monitor, and show the
initial-condition plot plus native solver results. Upload alone does not
initialize a model: the native scripts below consume the referenced file.

To demonstrate a changed initial condition, reference the `initial-plus15m`
variant under the **same baseline alias**, replacing the baseline reference
rather than creating duplicate aliases. Thickness rises exactly 15 m at every
grid point. Base and surface change hydrostatically; initial velocity stays
unchanged. A second paid launch requires the owner's existing run authorization.

Schema and scientific meaning
-----------------------------

Both formats contain schema `cryostack.shelf-initial-fields.v1`, a model label,
`synthetic=1`, ice/water densities 917/1028 kg m^-3, and temperature 253.15 K.
There are 9 x coordinates and 5 y coordinates, covering a 10 km square.
Two-dimensional arrays have shape `(ny,nx)=(5,9)`.

| HDF5 path | MAT `initial_conditions` member | Units |
|---|---|---|
| `/coordinates/x` | `x` | m |
| `/coordinates/y` | `y` | m |
| `/fields/thickness` | `thickness` | m |
| `/fields/base` | `base` | m |
| `/fields/surface` | `surface` | m |
| `/fields/vx` | `vx` | m/year |
| `/fields/vy` | `vy` | m/year |
| `/fields/floating_mask` | `floating_mask` | 1 (floating) |

HDF5 units are per-dataset attributes. MAT units are members of the `units`
struct. HDF5 root attributes contain the metadata; MAT metadata is stored in
the `initial_conditions` struct. MAT is standard v5 format loaded by MATLAB
`load`, with no extra package. HDF5 uses `h5py` and NumPy already represented
in the scientific image build recipe (`tools/cloud/Dockerfile:51–63` pins
`h5py==3.16.0` for the native Icepack/Firedrake environments). Preparation also
uses the existing VM h5py/SciPy environment; this is not a new image build.

The analytic thickness decreases with x from 500 to 300 m, with a small smooth
cross-flow variation. Velocity increases smoothly along x. Both primary data
cases put the calving front on the east edge, `x=L`, matching that direction.
The MAT contour surrounds that edge; canonical SquareIceShelf and preserved
source snapshots are unchanged. Floating geometry
obeys `base=-rho_ice/rho_water*thickness`, `surface=base+thickness` throughout.
The mask marks the complete domain floating, consistent with the shelf solvers.

Native initialization and evidence
----------------------------------

Icepack bilinearly interpolates the uploaded fields to every native mesh node.
The resulting `h0` and `u0` initialize the existing FlowSolver diagnostic and
prognostic solves. `b0` and `s0` initialize full base/surface fields; the loader
enforces hydrostatic consistency. Icepack's `IceShelf` equations consume
thickness and velocity and assume flotation, so base/surface are not separate
solver arguments. Vector-space coordinate nodes are sampled independently.

ISSM uses MATLAB `load` and `interp2` to initialize all of
`md.geometry.thickness`, `.base`, `.surface`, and `md.initialization.vx`, `.vy`,
`.vel` at every native mesh vertex. It sets the matching density constants,
uses the existing native SSA Stressbalance solve, and retains the standard
structured result path.

Both scripts save `outputs/initial-conditions.png` and the complete initialized
fields before solving, then keep native solver results. Icepack saves the
initialized arrays as NPZ; ISSM saves a MAT struct. These outputs make the
initialization inspectable beyond a single center value. Icepack's NPZ stores
`velocity_coordinates` from the vector space's own nodes alongside `velocity`;
its scalar `x`/`y` arrays must not be assumed to have the vector ordering.
`native-velocity-mapping-validation.json` checks that contract using different
scalar/vector node counts. The packet preview is
`plots/native-initial-conditions.png`: initial thickness, freeboard, speed,
changed thickness, the uniform +15 m difference, and floating base.

`native-formats-validation.json` records actual offline format, field,
interpolation and malformed-input checks. Full native solver execution and
MATLAB loader runtime acceptance are separate recorded outcomes; preparation
submits no AWS jobs and does not change production. NC/ZIP helpers and fixtures
remain available separately in `native-data-icepack/` and `native-data-issm/`.
`test_native_front.py` adds four calving-boundary checks; the actual MAT arrays'
eastward velocity and declining thickness are checked in
`native-front-validation.json`. The earlier JSON teaching source used a north
calving front with zero initial velocity; it and its checksum provenance remain
unchanged. The eastward full-field MAT case uses its own east-front contour.

Curated public HDF5/MAT examples only. Native Icepack HDF5 initialization/output checks passed for the retained run; MATLAB/MAT native acceptance remains separate. No raw operator metadata is included.
