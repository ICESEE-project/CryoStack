# Basic ISSM: byte-matched scientific source

These four files byte-match the actual submitted scientific files of the
18 November 2026 native SquareIceShelf execution. The match was checked against
that run's S3 input objects on the host; every object's LastModified preceded
submission. No mutable workspace file was used to reconstruct the input.

The complete submitted runtime contained 37 files. Private run wrappers and raw
job/license/account metadata are not distributed here; their complete input
snapshot is sealed privately, identified by the manifest's archive hash. This
packet contains only the already-public scientific example files that matched.
Original source attribution remains with the ISSM project. MATLAB and ISSM
binaries and license configuration are not included.

The case is a synthetic 1,000 km square with nominal 100 km triangles, thickness
1000 to 300 m along y, hydrostatic flotation, zero initial velocity and one SSA
Stressbalance solve configured for 2 MPI processes. It does not advance physical time.
The actual model log identified ISSM 2026.1; its AWS job definition pinned the
container digest in the accompanying manifest. A compatible installed model
and private institutional MATLAB configuration are required to rerun it.

Actual downloaded outputs passed archive CRC, finite-field, mesh/index and
velocity-component consistency checks. This is not a PC/AWS comparison or an
accepted video. MATLAB's version and mesh-generator seed provenance are not
fully captured; the manifest keeps those gaps visible. Numerical agreement
must be tested on actual same-input reruns with declared alignment/tolerances.
