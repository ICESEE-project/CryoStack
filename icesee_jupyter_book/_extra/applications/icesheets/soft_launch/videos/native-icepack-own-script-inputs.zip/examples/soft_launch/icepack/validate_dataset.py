"""Shared fixture contract. Run before importing scientific software."""
import json
import math
from pathlib import Path


def unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f'Duplicate field: {key}')
        obj[key] = value
    return obj


def validate(path, model):
    p=Path(path)
    if p.stat().st_size > 2 * 1024 * 1024:
        raise ValueError('Synthetic configuration exceeds 2 MiB')
    data=json.loads(p.read_text(), object_pairs_hook=unique_object,
                    parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Nonfinite number')))
    if not isinstance(data, dict) or data.get('schema') != 'cryostack.synthetic-shelf.v1':
        raise ValueError('Expected synthetic-shelf.v1 object')
    if data.get('model') != model or data.get('synthetic') is not True:
        raise ValueError('Wrong model or missing synthetic label')
    if data.get('units') != dict(length='m', thickness='m', temperature='K', velocity='m/year'):
        raise ValueError('Units must be m, K and m/year')
    ranges=dict(length_m=(100,100000), width_m=(100,100000),
                thickness_min_m=(1,2000), thickness_max_m=(1,2000),
                temperature_K=(200,273.15), mesh_nx=(2,32), mesh_ny=(2,32),
                mesh_spacing_m=(100,50000), inflow_velocity_m_per_year=(0,1000),
                timesteps=(1,6), dt_years=(0.0001,0.1))
    for key,(low,high) in ranges.items():
        v=data.get(key)
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not low <= v <= high:
            raise ValueError(f'{key} must be finite in [{low}, {high}]')
        if key in ('mesh_nx','mesh_ny','timesteps') and int(v)!=v:
            raise ValueError(f'{key} must be an integer')
    if data['thickness_max_m'] < data['thickness_min_m']:
        raise ValueError('Thickness maximum must be at least minimum')
    if data['mesh_spacing_m'] < min(data['length_m'],data['width_m'])/32:
        raise ValueError('Mesh exceeds the bounded launch case')
    return data

if __name__ == '__main__':
    import argparse
    a=argparse.ArgumentParser()
    a.add_argument('path'); a.add_argument('--model', choices=['issm','icepack'], required=True)
    args=a.parse_args(); validate(args.path,args.model); print('VALID')
