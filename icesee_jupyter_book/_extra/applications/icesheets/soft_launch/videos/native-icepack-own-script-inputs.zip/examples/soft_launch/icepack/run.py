"""Synthetic shelf: native Icepack solve; keep h/u globals for CryoLauncher export."""
import json
import time
from pathlib import Path
from validate_dataset import validate

started=time.monotonic()
p=Path('data/icepack-shelf-small-v1.json')
cfg=validate(p,'icepack')  # Validate before expensive imports or meshing.
import firedrake as fd
import icepack
import numpy as np
import matplotlib.pyplot as plt

mesh=fd.RectangleMesh(cfg['mesh_nx'],cfg['mesh_ny'],cfg['length_m'],cfg['width_m'])
Q=fd.FunctionSpace(mesh,'CG',1)
V=fd.VectorFunctionSpace(mesh,'CG',1)
x,y=fd.SpatialCoordinate(mesh)
h0=fd.Function(Q).interpolate(cfg['thickness_max_m'] +
    (cfg['thickness_min_m']-cfg['thickness_max_m'])*x/cfg['length_m'])
u0=fd.Function(V).interpolate(fd.as_vector((cfg['inflow_velocity_m_per_year']*(1+x/cfg['length_m']),0)))
h=h0.copy(deepcopy=True)
A=icepack.rate_factor(fd.Constant(cfg['temperature_K']))
solver=icepack.solvers.FlowSolver(icepack.models.IceShelf(),dirichlet_ids=[1],side_wall_ids=[3,4])
u=solver.diagnostic_solve(velocity=u0,thickness=h,fluidity=A)
a=fd.Function(Q).assign(0)
for step in range(cfg['timesteps']):
    h=solver.prognostic_solve(cfg['dt_years'],thickness=h,velocity=u,accumulation=a,thickness_inflow=h0)
    u=solver.diagnostic_solve(velocity=u,thickness=h,fluidity=A)
    print(f'SOFT_LAUNCH step={step+1}/{cfg["timesteps"]}',flush=True)
assert np.isfinite(h.dat.data_ro).all() and np.min(h.dat.data_ro)>0
assert np.isfinite(u.dat.data_ro).all()
metrics=dict(model='icepack',case='synthetic-shelf-v1',steps=cfg['timesteps'],
             thickness_min=float(h.dat.data_ro.min()),thickness_max=float(h.dat.data_ro.max()),
             thickness_mean=float(fd.assemble(h*fd.dx)/(cfg['length_m']*cfg['width_m'])),
             speed_l2=float(np.sqrt(fd.assemble(fd.inner(u,u)*fd.dx)/(cfg['length_m']*cfg['width_m']))),
             runtime_seconds=time.monotonic()-started)
Path('outputs').mkdir(exist_ok=True)
Path('outputs/reference-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
fig,axes=plt.subplots(); colors=fd.tripcolor(h,axes=axes); fig.colorbar(colors,ax=axes,label='Thickness (m)')
axes.set_title('Synthetic shelf: final thickness'); print(json.dumps(metrics),flush=True)
